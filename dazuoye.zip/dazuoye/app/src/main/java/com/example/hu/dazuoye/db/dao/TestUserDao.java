package com.example.hu.dazuoye.db.dao;

import android.test.AndroidTestCase;

/**
 * Created by ken on 2018/1/6.
 */

public class TestUserDao extends AndroidTestCase{

    public void test1(){
        UserDao udao = new UserDao(getContext());

        udao.insert("zs","user1","123456", 100);
        udao.insert("ls","user2","123456", 100);
    }
    public void test2(){
        UserDao udao = new UserDao(getContext());

        udao.delete("user1");
    }
    public void test3(){
        UserDao udao = new UserDao(getContext());

        udao.reCharge("user1", 50);
    }
    public void test4(){
        UserDao udao = new UserDao(getContext());

        udao.updatepassword("user1","123");
    }
    public void test5(){
        UserDao udao = new UserDao(getContext());


        String balance = udao.findBalance("user1");
        System.out.println("余额:" + balance);
    }
    public void test6(){
        UserDao udao = new UserDao(getContext());

        String password = udao.findPassword("user1");
        System.out.println("余额:" + password);
    }

}
